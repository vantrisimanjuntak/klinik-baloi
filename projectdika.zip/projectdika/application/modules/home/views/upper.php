<div class="header_top">
    <div class="container-fluid ">
        <div class="contact_nav">
            <a href="">
                <i class="fa fa-phone" aria-hidden="true"></i>
                <span>
                    Call : +01 123455678990
                </span>
            </a>
            <a href="">
                <i class="fa fa-envelope" aria-hidden="true"></i>
                <span>
                    Email : demo@gmail.com
                </span>
            </a>
            <a href="">
                <i class="fa fa-map-marker" aria-hidden="true"></i>
                <span>
                    Location
                </span>
            </a>
        </div>
    </div>
</div>