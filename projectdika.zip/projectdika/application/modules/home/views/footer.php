<section class="footer_section">
    <div class="container-fluid" style="background-color: black">
    <div class="row pt-4">
        <img src="<?= base_url('assets/images/logo-ppid.png') ?>" style="max-width:180px;" alt="">
        <div class="col-md-4">
            <p class="text-white text-left">Dalam rangka mewujudkan open goverment Indonesia dan sebagai implementasi Undang-Undang Nomor 25 Tahun 2009, Badan Pengusaha Batam yang merupakan institusi pemerintah melakukan berbagai cara dan upaya untuk peningkatan pelayanan publik, diantaranya dengan pengelolaan sistem informasi pelayanan publik. Pengelolaan ini dibuat dan dirancang untuk mempermundah komunikasi dan interaksi antara publik dengan Badan Pengusaha Batam</p>
        </div>
        <div class="col-md-4">
            <img src="<?= base_url('assets/images/logo-ppid.png') ?>" style="max-width:180px;" alt="">
            <p class="text-white text-left">Dalam rangka mewujudkan open goverment Indonesia dan sebagai implementasi Undang-Undang Nomor 25 Tahun 2009, Badan Pengusaha Batam yang merupakan institusi pemerintah melakukan berbagai cara dan upaya untuk peningkatan pelayanan publik, diantaranya dengan pengelolaan sistem informasi pelayanan publik. Pengelolaan ini dibuat dan dirancang untuk mempermundah komunikasi dan interaksi antara publik dengan Badan Pengusaha Batam</p>
        </div>
        <div class="col-md-4">
            <img src="<?= base_url('assets/images/logo-ppid.png') ?>" style="max-width:180px;" alt="">
            <p class="text-white text-left">Dalam rangka mewujudkan open goverment Indonesia dan sebagai implementasi Undang-Undang Nomor 25 Tahun 2009, Badan Pengusaha Batam yang merupakan institusi pemerintah melakukan berbagai cara dan upaya untuk peningkatan pelayanan publik, diantaranya dengan pengelolaan sistem informasi pelayanan publik. Pengelolaan ini dibuat dan dirancang untuk mempermundah komunikasi dan interaksi antara publik dengan Badan Pengusaha Batam</p>
        </div>
    </div>
        <p>
            &copy; <span id="displayYear"></span> All Rights Reserved By
            <a href="https://html.design/">Free Html Templates</a>
            Distributed By
            <a href="https://themewagon.com">ThemeWagon</a>
        </p>
    </div>
</section>