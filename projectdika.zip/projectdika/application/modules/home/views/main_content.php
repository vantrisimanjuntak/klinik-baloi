<section class="banner">
    <div class="container-fluid no-padding px-0">
        <div class="row">
            <div class="col-md-12">
                <!-- <img class='img-fluid w-100' src="<?= base_url('assets/images/hospital.jpg') ?>" alt="" srcset=""> -->
                <h1 class="text-white font-weight-bold">Rumah Sakit BP Batam</h1>
            </div>
        </div>
    </div>
</section>

<div class="container p-3 mb-5 thumb rounded">
    <div class="container w-75 pt-4">
        <h2 class="text-primary font-weight-bold pb-4">Fasilitas RSOB</h2>
        <p>Pelayanan Transfusi Darah</p>
        <p>Pelayanan Rehabilitas Medik</p>
        <p>Pelayanan Rekam Medik</p>
        <p>Pelayanan Rawat Jalan</p>
    </div>
</div>